from django.contrib import admin
from .models import Member, Employee

admin.site.register(Member)
admin.site.register(Employee)



